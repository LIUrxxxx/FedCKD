import numpy as np

test=np.load('D:\PersonalizedFL-main\split\medmnist0.1\partion_non_iid_dirichlet_0.01_20.npy')

print(test)
