import matplotlib.pyplot as plt
import matplotlib as mpl

def openfile(filepath):
    file = open(filepath)
    y = []
    while 1:
        line = file.readline()
        if line.rstrip('\n') == '':
            break
        y.append(float(line.rstrip('\n')))
        if not line:
            break
        pass
    file.close()
    return y

if __name__ == '__main__':
    mpl.use('TkAgg')
    # plt.figure()
    # alg_array = ['5', '10', '15', '20']
    # plt.ylabel('Accuracy')
    # plt.xlabel('Global Round')
    # for alg in alg_array:
    #     y = openfile('./result/ckdfed_pamap_100_iid0.1_wk1_threshold1.1_cli{}_tacc.dat'.format(alg))
    #     plt.plot(range(99), y, label=r'${}$'.format(alg))
    # #plt.title('')
    # plt.legend()
    # plt.savefig('Client_pamap(5-20).png')

    # plt.figure()
    # alg_array = ['fedckd']
    # plt.ylabel('Accuracy')
    # plt.xlabel('Global Round')
    # for alg in alg_array:
    #     y = openfile('./result/{}_pamap_150_iid0.1_wk1_threshold1.1_tacc.dat'.format(alg))
    #     plt.plot(range(149), y, label=r'${}$'.format(alg))
    # #plt.title('Convergence')
    # plt.legend()
    # plt.savefig('Convergence.png')

    plt.figure()
    alg_array = ['fedckd', 'fedavg', 'fedap', 'fedprox']
    plt.ylabel('Accuracy')
    plt.xlabel('Global Round')
    for alg in alg_array:
        y = openfile('./result/{}_medmnist_150_iid0.1_wk1_threshold1.1_tacc.dat'.format(alg))
        plt.plot(range(149), y, label=r'${}$'.format(alg))
    plt.legend()
    plt.savefig('Comparison_medmnist2.png')

