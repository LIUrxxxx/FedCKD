import numpy as np

import torch
import torch.nn as nn
import torch.optim as optim
import copy

from util.modelsel import modelsel
from util.traineval import trainwithteacher, test
from sklearn.cluster import Birch, KMeans
from util.tools import vectorize

class ckdfed(torch.nn.Module):
    def __init__(self, args):
        super(ckdfed, self).__init__()
        self.server_model, self.client_model, self.client_weight = modelsel(
            args, args.device)
        self.optimizers = [optim.SGD(params=self.client_model[idx].parameters(
        ), lr=args.lr) for idx in range(args.n_clients)]
        self.loss_fun = nn.CrossEntropyLoss()
        self.args = args
        args.sort = ''
        for i in range(args.n_clients):
            args.sort += '%d-' % i
        args.sort = args.sort[:-1]
        self.args = args
        self.csort = [int(item) for item in args.sort.split('-')]

        self.delta_list = [None for _ in self.client_model]
        self.similarity_matrix = np.eye(len(self.client_model))

    def init_model_flag(self, train_loaders, val_loaders):
        self.flagl = []
        client_num = self.args.n_clients
        for _ in range(client_num):
            self.flagl.append(False)
        optimizers = [optim.SGD(params=self.client_model[idx].parameters(
        ), lr=self.args.lr) for idx in range(client_num)]
        for idx in range(client_num):
            client_idx = idx
            model, train_loader, optimizer, tmodel, val_loader = self.client_model[
            client_idx], train_loaders[client_idx], optimizers[client_idx], None, val_loaders[idx]

            for _ in range(30):
                _, _ = trainwithteacher(
                    model, train_loader, optimizer, self.loss_fun, self.args.device, tmodel, 1, self.args, False)
            _, val_acc = test(model, val_loader, self.loss_fun, self.args.device)

        self.compute_pairwise_similarity()

        # 使用 Canopy 聚类算法获得初始聚类中心
        canopy = Birch(n_clusters=None, threshold=1.0, branching_factor=10)
        canopy_clusters = canopy.fit_predict(self.similarity_matrix)

        # 使用 Canopy 聚类的结果作为 K-Means 初始 k 值
        initial_k = len(set(canopy_clusters))

        # 使用 K-Means 聚类算法进行最终聚类
        kmeans = KMeans(n_clusters=initial_k, random_state=0)
        kmeans_clusters = kmeans.fit_predict(self.similarity_matrix)

        # 获取聚类数目
        num_clusters = len(set(kmeans_clusters))

        # 对每个聚类域执行模型平均聚合
        for cluster in range(num_clusters):
            # 获取当前聚类域内的客户端索引
            cluster_indices = [i for i, label in enumerate(kmeans_clusters) if label == cluster]
            # 获取当前聚类域内的客户端模型和数据
            cluster_models = [self.client_model[idx] for idx in cluster_indices]
            cluster_train_loaders = [train_loaders[idx] for idx in cluster_indices]

            # 平均聚合客户端模型
            averaged_model = self.average_models(cluster_models)

            # 在验证集上评估聚合后的模型
            _, val_acc = test(averaged_model, val_loader, self.loss_fun, self.args.device)

            # 根据验证准确率设置标志
            if val_acc > self.args.threshold:
                for idx in cluster_indices:
                    self.flagl[idx] = True
            # 执行知识蒸馏
            for idx in cluster_indices:
                client_model = self.client_model[idx]
                train_loader = cluster_train_loaders[idx]
                optimizer = optim.SGD(params=client_model.parameters(), lr=self.args.lr)

                # 使用 averaged_model 作为教师模型进行知识蒸馏
                _, _ = trainwithteacher(client_model, train_loader, optimizer, self.loss_fun, self.args.device,
                                        averaged_model, 1, self.args, False)
            if self.args.dataset in ['vlcs', 'pacs']:
                self.thes = 0.4
            elif 'medmnist' in self.args.dataset:
                self.thes = 0.5
            elif 'pamap' in self.args.dataset:
                self.thes = 0.5
            else:
                self.thes = 0.5

    @torch.no_grad()
    def compute_pairwise_similarity(self):
        self.similarity_matrix = np.eye(len(self.client_model))
        for i, delta_a in enumerate(self.delta_list):
            for j, delta_b in enumerate(self.delta_list[i + 1:], i + 1):
                if delta_a is not None and delta_b is not None:
                    score = torch.cosine_similarity(
                        vectorize(delta_a), vectorize(delta_b), dim=0, eps=1e-12
                    ).item()
                    self.similarity_matrix[i, j] = score
                    self.similarity_matrix[j, i] = score

    def average_models(self, models):
        # 对模型列表进行平均聚合
        averaged_model = copy.deepcopy(models[0])
        for param in averaged_model.parameters():
            param.data *= 0.0

        num_models = len(models)

        for model in models:
            for param_avg, param_model in zip(averaged_model.parameters(), model.parameters()):
                param_avg.data += param_model.data / num_models

        return averaged_model

    def update_flag(self, val_loaders):
        for client_idx, model in enumerate(self.client_model):
            _, val_acc = test(
                model, val_loaders[client_idx], self.loss_fun, self.args.device)
            if val_acc > self.args.threshold:
                self.flagl[client_idx] = True

    def client_train(self, c_idx, dataloader, round):
        client_idx = self.csort[c_idx]
        tidx = self.csort[c_idx-1]
        model, train_loader, optimizer, tmodel = self.client_model[
            client_idx], dataloader, self.optimizers[client_idx], self.client_model[tidx]
        if round == 0 and c_idx == 0:
            tmodel = None
        for _ in range(self.args.wk_iters):
            train_loss, train_acc = trainwithteacher(
                model, train_loader, optimizer, self.loss_fun, self.args.device, tmodel, self.args.lam, self.args, self.flagl[client_idx])
        return train_loss, train_acc

    def personalization(self, c_idx, dataloader, val_loader):
        client_idx = self.csort[c_idx]
        model, train_loader, optimizer, tmodel = self.client_model[
            client_idx], dataloader, self.optimizers[client_idx], copy.deepcopy(self.client_model[self.csort[-1]])

        with torch.no_grad():
            _, v1a = test(model, val_loader, self.loss_fun, self.args.device)
            _, v2a = test(tmodel, val_loader, self.loss_fun, self.args.device)

        if v2a <= v1a and v2a < self.thes:
            lam = 0
        else:
            lam = (10**(min(1, (v2a-v1a)*5)))/10*self.args.lam

        for _ in range(self.args.wk_iters):
            train_loss, train_acc = trainwithteacher(
                model, train_loader, optimizer, self.loss_fun, self.args.device, tmodel, lam, self.args, self.flagl[client_idx])
        return train_loss, train_acc

    def client_eval(self, c_idx, dataloader):
        train_loss, train_acc = test(
            self.client_model[c_idx], dataloader, self.loss_fun, self.args.device)
        return train_loss, train_acc



