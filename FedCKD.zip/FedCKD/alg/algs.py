from alg.fedavg import fedavg
from alg.base import base
from alg.ckdfed import ckdfed
from alg.fedKD import fedKD
from alg.fedap import fedap
from alg.fedprox import fedprox

ALGORITHMS = [
    'fedavg',
    'base',
    'ckdfed',
    'fedap',
    'fedprox',
    'fedKD'
]


def get_algorithm_class(algorithm_name):
    """Return the algorithm class with the given name."""
    if algorithm_name not in globals():
        raise NotImplementedError(
            "Algorithm not found: {}".format(algorithm_name))
    return globals()[algorithm_name]
