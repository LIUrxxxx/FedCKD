import numpy as np
import torch

from sklearn.cluster import KMeans
from sklearn.datasets import make_blobs


class clustering(torch.nn.Module):
    # 定义Canopy方法
    def canopy(client_data, T1, T2):
        canopies = []
        canopy_centers = []

        client_data = [make_blobs(n_samples=100, centers=3, random_state=i)[0] for i in range(1, 4)]  # 三个客户端的数据

        # 超参数
        T1 = 1.0  # Canopy方法的T1阈值
        T2 = 0.5  # Canopy方法的T2阈值

        while len(client_data) > 0:
            center = client_data[0]
            canopy_center = [center]
            client_data = client_data[1:]

            remove_list = []
            for point in client_data:
                distance = np.linalg.norm(center - point)

                if distance < T1:
                    canopy_center.append(point)
                if distance < T2:
                    remove_list.append(point)

            for point in remove_list:
                client_data.remove(point)

            canopy_centers.append(center)
            canopies.append(canopy_center)

        return canopy_centers, canopies

        # 计算客户端之间的相似度矩阵
        similarity_matrix = np.zeros((len(client_data), len(client_data)))
        for i in range(len(client_data)):
            for j in range(i + 1, len(client_data)):
                # 使用某种相似度度量方法计算相似度，这里假设使用欧几里得距离
                similarity = np.linalg.norm(np.mean(client_data[i], axis=0) - np.mean(client_data[j], axis=0))
                similarity_matrix[i, j] = similarity
                similarity_matrix[j, i] = similarity

        # 基于相似度矩阵进行Canopy聚类
        canopy_centers, _ = canopy(similarity_matrix, T1, T2)

        # 使用Canopy中心点数量作为K均值聚类的K值
        K = len(canopy_centers)

        # 对每个客户端进行K均值聚类，划分为K个聚类域
        cluster_domains = []
        for i, client in enumerate(client_data):
            kmeans = KMeans(n_clusters=K, random_state=0).fit(client)
            cluster_domains.append({
                "client_id": i,
                "cluster_labels": kmeans.labels_
            })

        # 打印每个客户端的聚类结果
        #for domain in cluster_domains:
        #    print(f"Client {domain['client_id']} Cluster Labels:")
        #    print(domain['cluster_labels'])

