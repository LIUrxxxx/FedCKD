import matplotlib.pyplot as plt
import matplotlib as mpl

def openfile(filepath):
    file = open(filepath)
    y = []
    while 1:
        line = file.readline()
        if line.rstrip('\n') == '':
            break
        y.append(float(line.rstrip('\n')))
        if not line:
            break
        pass
    file.close()
    return y

if __name__ == '__main__':
    mpl.use('TkAgg')
    plt.figure()
    alg_array = ['Shuffle', 'Gaussian', 'Laplace', 'MA', 'no-dp']
    plt.ylabel('Accuracy')
    plt.xlabel('Global Round')
    for alg in alg_array:
        y = openfile('./log/accfile_fed_mnist_cnn_200_C0.2_iidFalse_dp_{}_epsilon_20.0.dat'.format(alg))
        plt.plot(range(200), y, label=r'${}$'.format(alg))
    #plt.title('Convergence')
    plt.legend()
    plt.savefig('C0.2_All.png')


