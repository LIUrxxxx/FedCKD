# Copyright (c) Microsoft Corporation.
# Licensed under the MIT License.

import os
import numpy as np
import torch
import argparse
import matplotlib.pyplot as plt

from datautil.prepare_data import *
from util.config import img_param_init, set_random_seed
from util.evalandprint import evalandprint
from alg import algs

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--alg', type=str, default='ckdfed',
                        help='Algorithm to choose: [base | fedavg | fedbn | fedprox | fedap | ckdfed ]')
    parser.add_argument('--datapercent', type=float,
                        default=1e-1, help='data percent to use')
    parser.add_argument('--dataset', type=str, default='medmnist',
                        help='[vlcs | pacs | officehome | pamap | covid | medmnist]')
    parser.add_argument('--root_dir', type=str,
                        default='./data/', help='data path')
    parser.add_argument('--save_path', type=str,
                        default='./cks/', help='path to save the checkpoint')
    parser.add_argument('--device', type=str,
                        default='cpu', help='[cuda | cpu]')
    parser.add_argument('--batch', type=int, default=32, help='batch size')
    parser.add_argument('--iters', type=int, default=300,
                        help='iterations for communication')
    parser.add_argument('--lr', type=float, default=1e-2, help='learning rate')
    parser.add_argument('--n_clients', type=int,
                        default=25, help='number of clients')
    parser.add_argument('--non_iid_alpha', type=float,
                        default=0.1, help='data split for label shift')
    parser.add_argument('--partition_data', type=str,
                        default='non_iid_dirichlet', help='partition data way')
    parser.add_argument('--plan', type=int,
                        default=1, help='choose the feature type')
    parser.add_argument('--pretrained_iters', type=int,
                        default=150, help='iterations for pretrained models')
    parser.add_argument('--seed', type=int, default=0, help='random seed')
    parser.add_argument('--wk_iters', type=int, default=1,
                        help='optimization iters in local worker between communication')
    parser.add_argument('--nosharebn', action='store_true',
                        help='not share bn')

    # algorithm-specific parameters
    parser.add_argument('--mu', type=float, default=1e-3,
                        help='The hyper parameter for fedprox')
    parser.add_argument('--threshold', type=float, default=0.6,
                        help='threshold to use copy or distillation, hyperparmeter for ckdfed')
    parser.add_argument('--lam', type=float, default=1.0,
                        help='init lam, hyperparmeter for ckdfed')
    parser.add_argument('--model_momentum', type=float,
                        default=0.5, help='hyperparameter for fedap')
    args = parser.parse_args()

    args.random_state = np.random.RandomState(1)
    set_random_seed(args.seed)

    if args.dataset in ['vlcs', 'pacs', 'off_home']:
        args = img_param_init(args)
        args.n_clients = 4

    exp_folder = f'fed_{args.dataset}_{args.alg}_{args.datapercent}_{args.non_iid_alpha}_{args.mu}_{args.model_momentum}_{args.plan}_{args.lam}_{args.threshold}_{args.iters}_{args.wk_iters}'
    if args.nosharebn:
        exp_folder += '_nosharebn'
    args.save_path = os.path.join(args.save_path, exp_folder)
    if not os.path.exists(args.save_path):
        os.makedirs(args.save_path)
    SAVE_PATH = os.path.join(args.save_path, args.alg)

    data_loaders = get_data(args.dataset)(args)

    if len(data_loaders) == 3:
        train_loaders, val_loaders, test_loaders = data_loaders
    elif len(data_loaders) == 4:
        train_loaders, val_loaders, test_loaders = data_loaders
    else:
        raise ValueError("Unexpected number of elements returned by get_data")

    # 确保你的数据加载器在这里得到了正确的值

    algclass = algs.get_algorithm_class(args.alg)(args)

    if args.alg == 'fedap':
        algclass.set_client_weight(train_loaders)
    elif args.alg == 'ckdfed':
        algclass.init_model_flag(train_loaders, val_loaders)
        args.iters = args.iters-1
        print('Common knowledge accumulation stage')
    elif args.alg == 'fedKD':
        algclass.init_model_flag(train_loaders, val_loaders)
        args.iters = args.iters-1
        print('Common knowledge accumulation stage')

    best_changed = False

    best_acc = [0] * args.n_clients
    best_tacc = [0] * args.n_clients
    start_iter = 1

    # 定义结果文件夹路径
    result_folder = 'result'
    os.makedirs(result_folder, exist_ok=True)  # 确保结果文件夹存在，如果不存在则创建

    # 定义一个空列表来存储每一轮的平均验证准确率
    avg_train_acc_per_round = []
    avg_val_acc_per_round = []

    for a_iter in range(start_iter, args.iters):
        print(f"============ Train round {a_iter} ============")

        if args.alg == 'ckdfed':
            for c_idx in range(args.n_clients):
                algclass.client_train(
                    c_idx, train_loaders[algclass.csort[c_idx]], a_iter)
            algclass.update_flag(val_loaders)
        elif args.alg == 'fedKD':
            for c_idx in range(args.n_clients):
                algclass.client_train(
                    c_idx, train_loaders[algclass.csort[c_idx]], a_iter)
            algclass.update_flag(val_loaders)
        else:
            # local client training
            for wi in range(args.wk_iters):
                for client_idx in range(args.n_clients):
                    algclass.client_train(
                        client_idx, train_loaders[client_idx], a_iter)

            # server aggregation
            algclass.server_aggre()

        best_acc, best_tacc, best_changed = evalandprint(
            args, algclass, train_loaders, val_loaders, test_loaders, SAVE_PATH, best_acc, best_tacc, a_iter, best_changed)

        # 从evalandprint函数中收集平均验证准确率
        total_train_loss = 0.0
        total_train_acc = 0.0
        for client_idx in range(args.n_clients):
            train_loss, train_acc = algclass.client_eval(
                client_idx, train_loaders[client_idx])
            total_train_loss += train_loss
            total_train_acc += train_acc

        # 计算平均训练损失和准确率
        avg_train_loss = total_train_loss / args.n_clients
        avg_train_acc = (total_train_acc / args.n_clients) *100
        avg_train_acc_per_round.append(avg_train_acc)

        total_val_loss = 0.0
        total_val_acc = 0.0
        val_acc_list = [None] * args.n_clients
        for client_idx in range(args.n_clients):
            val_loss, val_acc = algclass.client_eval(
                client_idx, val_loaders[client_idx])
            val_acc_list[client_idx] = val_acc
            total_val_loss += val_loss
            total_val_acc += val_acc

        avg_val_acc = (total_val_acc / args.n_clients) * 100
        avg_val_acc_per_round.append(avg_val_acc)

    if args.alg == 'ckdfed':
        print('Personalization stage')
        for c_idx in range(args.n_clients):
            algclass.personalization(
                c_idx, train_loaders[algclass.csort[c_idx]], val_loaders[algclass.csort[c_idx]])
        best_acc, best_tacc, best_changed = evalandprint(
            args, algclass, train_loaders, val_loaders, test_loaders, SAVE_PATH, best_acc, best_tacc, a_iter, best_changed)
    elif args.alg == 'fedKD':
        print('Personalization stage')
        for c_idx in range(args.n_clients):
            algclass.personalization(
                c_idx, train_loaders[algclass.csort[c_idx]], val_loaders[algclass.csort[c_idx]])
        best_acc, best_tacc, best_changed = evalandprint(
            args, algclass, train_loaders, val_loaders, test_loaders, SAVE_PATH, best_acc, best_tacc, a_iter, best_changed)

    s = 'Personalized test acc for each client: '
    for item in best_tacc:
        s += f'{item:.4f},'
    mean_acc_test = np.mean(np.array(best_tacc))
    s += f'\nAverage accuracy: {mean_acc_test:.4f}'
    print(s)

    rootpath = './result'
    if not os.path.exists(rootpath):
        os.makedirs(rootpath)
    accfile = open(rootpath + '/{}_{}_{}_iid{}_wk{}_threshold{}_cli{}_tacc.dat'.
                   format(args.alg, args.dataset, args.iters, args.non_iid_alpha,
                          args.wk_iters, args.threshold, args.n_clients), "w")

    for ac in avg_train_acc_per_round:
        sac = str(ac)
        accfile.write(sac)
        accfile.write('\n')
    accfile.close()

    # 创建x轴（通信轮次）和y轴（平均验证准确率）的数据
    communication_rounds = list(range(start_iter, args.iters))

    # 绘制折线图
    plt.plot(communication_rounds, avg_train_acc_per_round)
    plt.ylim(0, 100)  # 设置纵轴范围为从0到1
    plt.title('Average Train Accuracy per Communication Round')
    plt.xlabel('Communication Round')
    plt.ylabel('Average Train Accuracy')
    plt.grid(True)

    # 保存折线图到结果文件夹
    plt.savefig(rootpath + '/{}_{}_{}_iid{}_wk{}_threshold{}_cli{}_tacc.png'.format(
        args.alg, args.dataset, args.iters, args.non_iid_alpha, args.wk_iters,
        args.threshold, args.n_clients))

    # 绘制折线图
    #plt.plot(communication_rounds, avg_val_acc_per_round)
    #plt.ylim(0, 100)  # 设置纵轴范围为从0到100
    #plt.title('Average Validation Accuracy per Communication Round')
    #plt.xlabel('Communication Round')
    #plt.ylabel('Average Validation Accuracy')
    #plt.grid(True)

    # 保存折线图到结果文件夹
    #plt.savefig(rootpath + '/{}_{}_{}_iid{}_{}_{}_vacc.png'.format(
    #    args.alg, args.dataset, args.iters, args.non_iid_alpha, args.wk_iters, args.threshold))

    # 显示绘制的折线图
    plt.show()
