# privacy
python dp.py --dataset mnist --dp_mechanism no_dp --gpu 1
python dp.py --dataset mnist --dp_mechanism Shuffle --gpu 1
python dp.py --dataset mnist --dp_mechanism Gaussian --dp_epsilon 25 --dp_clip 10 --gpu 1
python dp.py --dataset mnist --dp_mechanism Laplace --dp_epsilon 20 --dp_clip 50 --gpu 1 --frac 0.2
python dp.py --dataset mnist --dp_mechanism MA --dp_epsilon 20 --dp_clip 10 --gpu 1 --dp_sample 0.01


python main.py --alg ckdfed --dataset medmnist --iters 150 --wk_iters 1 --non_iid_alpha 0.1
python main.py --alg fedKD --dataset medmnist --iters 150 --wk_iters 1 --non_iid_alpha 0.1
python main.py --alg fedavg --dataset medmnist --iters 150 --wk_iters 1 --non_iid_alpha 0.1
python main.py --alg fedap --dataset medmnist --iters 150 --wk_iters 1 --non_iid_alpha 0.1
python main.py --alg fedprox --dataset medmnist --iters 150 --wk_iters 1 --non_iid_alpha 0.1


get_char()
{
SAVEDSTTY=`stty -g`
stty -echo
stty cbreak
dd if=/dev/tty bs=1 count=1 2> /dev/null
stty -raw
stty echo
stty $SAVEDSTTY
}
echo "Press any key to continue!"
char=`get_char`
